#!/usr/bin/env bash
set -euo pipefail
echo "Installer placeholder. Copy portsnap-secure.py to /usr/local/bin and make executable."
