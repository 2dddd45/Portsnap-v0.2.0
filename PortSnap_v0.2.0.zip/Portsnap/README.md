# PortSnap Final with Wrapper

This package contains:
- portsnap-secure.py  (main tool)
- install.sh          (installer placeholder)
- portsnap            (wrapper script providing shortcuts: -p, -g, -l)
- README files and examples

How to install wrapper globally:
1. Copy portsnap-secure.py to /usr/local/bin/portsnap-secure and make it executable:
   sudo cp portsnap-secure.py /usr/local/bin/portsnap-secure
   sudo chmod +x /usr/local/bin/portsnap-secure

2. Copy the wrapper to /usr/local/bin/portsnap and make executable:
   sudo cp portsnap /usr/local/bin/portsnap
   sudo chmod +x /usr/local/bin/portsnap

Usage examples:
  portsnap -p                     # set password (runs sudo portsnap-secure set-password)
  portsnap -g 192.168.1.10 --interval 60 --outdir ./reports
  portsnap -l ./reports           # list reports folder (or default /var/log/portsnap-secure)
  portsnap scan 10.0.0.5 -p 22,80

Note: wrapper calls portsnap-secure with sudo. Remove 'sudo' from wrapper if you adjusted permissions
so it can run without root.
