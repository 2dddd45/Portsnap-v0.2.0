#!/usr/bin/env python3
"""
PortSnap Secure - final enhanced version
Features:
- Nice ASCII banner & colored output (good CLI design)
- PBKDF2 password protection stored at /etc/portsnap.pass (set-password / clear-password)
- Multithreaded TCP scanning (fast)
- Save reports in txt/json/csv
- Monitor (periodic scans) and start alias
- Optional Telegram notifications via /etc/portsnap_tele.conf (JSON {"webhook": "..."})
- Simple argcomplete-friendly argparse layout
"""
import argparse, getpass, os, sys, socket, time, json, csv, hashlib, secrets, logging
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import urllib.request, urllib.parse

# Configuration paths
PASSFILE = Path("/etc/portsnap.pass")
TELECONF = Path("/etc/portsnap_tele.conf")
LOGDIR = Path("/var/log/portsnap-secure")

# Setup logging (rotating handled by systemd or logrotate; keep simple here)
LOGDIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(filename=str(LOGDIR/"portsnap.log"), level=logging.INFO,
                    format="%(asctime)s %(levelname)s: %(message)s")

# Banner & colors
BANNER = r"""
██████╗  ██████╗ ███████╗███████╗██████╗ ███╗   ██╗██████╗ 
██╔══██╗██╔═══██╗██╔════╝██╔════╝██╔══██╗████╗  ██║██╔══██╗
██████╔╝██║   ██║█████╗  █████╗  ██████╔╝██╔██╗ ██║██║  ██║
██╔═══╝ ██║   ██║██╔══╝  ██╔══╝  ██╔══██╗██║╚██╗██║██║  ██║
██║     ╚██████╔╝███████╗███████╗██║  ██║██║ ╚████║██████╔╝
╚═╝      ╚═════╝ ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ 
            PortSnap Secure / Open Readme File !!!
"""
def color(text, code): return f"\033[{code}m{text}\033[0m"
def info(s): print(color("[i] ","34")+s); logging.info(s)
def ok(s): print(color("[✔] ","32")+s); logging.info(s)
def warn(s): print(color("[!] ","33")+s); logging.warning(s)
def error(s): print(color("[✖] ","31")+s); logging.error(s)

def print_dashboard():
    print("-"*64)
    print("  Quick commands: set-password | clear-password | scan | monitor | start")
    print("  Reports: txt / json / csv -> use --outdir to save")
    print("-"*64)

# Password utilities (PBKDF2-HMAC-SHA256)
def hash_password(password, salt=None):
    if salt is None:
        salt = secrets.token_bytes(16)
    else:
        salt = bytes.fromhex(salt)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200000)
    return salt.hex(), dk.hex()

def save_passfile(salt_hex, dk_hex):
    try:
        PASSFILE.write_text(salt_hex + ":" + dk_hex + "\n")
        os.chmod(PASSFILE, 0o600)
        ok(f"Password saved to {PASSFILE}")
    except PermissionError:
        error("Permission denied: run set-password as root (sudo).")

def load_passfile():
    if not PASSFILE.exists(): return None, None
    data = PASSFILE.read_text().strip()
    if ":" not in data: return None, None
    salt, dk = data.split(":",1)
    return salt, dk

def verify_password_interactive(prompt="Password: "):
    salt, dk = load_passfile()
    if not salt:
        return False
    pw = getpass.getpass(prompt)
    _, try_dk = hash_password(pw, salt=salt)
    return try_dk == dk

# Scanning (multithreaded TCP connect)
def _try_connect(host, port, timeout):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            res = s.connect_ex((host, port))
            if res == 0:
                return port
    except Exception:
        return None
    return None

def scan_host_mt(host, ports, timeout=0.8, workers=100):
    open_ports = []
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_try_connect, host, p, timeout): p for p in ports}
        for fut in as_completed(futures):
            r = fut.result()
            if r:
                open_ports.append(r)
    return sorted(open_ports)

# Reporting
def write_report(outdir, host, open_ports, fmt="txt"):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    basefn = outdir / f"portsnap_{host}_{ts}"
    if fmt == "json":
        fn = basefn.with_suffix(".json")
        fn.write_text(json.dumps({"host": host, "timestamp": ts, "open": open_ports}, indent=2))
    elif fmt == "csv":
        fn = basefn.with_suffix(".csv")
        with open(fn, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["host","timestamp","port"])
            for p in open_ports:
                w.writerow([host, ts, p])
    else:
        fn = basefn.with_suffix(".txt")
        with open(fn, "w") as f:
            f.write(f"# PortSnap report — host: {host} — UTC {ts}\n")
            if open_ports:
                f.write("Open TCP ports:\n")
                for p in open_ports:
                    f.write(f"- {p}\n")
            else:
                f.write("No open TCP ports found in scanned ports.\n")
    ok(f"Saved report to {fn}")
    return fn

# Telegram notifier (optional)
def send_telegram_if_configured(message):
    if not TELECONF.exists(): return False
    try:
        cfg = json.loads(TELECONF.read_text())
        webhook = cfg.get("webhook")
        if not webhook: return False
        # If webhook is full sendMessage URL, append text param
        if "sendMessage" in webhook or "api.telegram.org" in webhook:
            url = webhook + ("&text=" if "?" in webhook else "?text=") + urllib.parse.quote(message)
            urllib.request.urlopen(url, timeout=6)
            return True
    except Exception as e:
        logging.exception("Telegram notify failed")
    return False

# Commands
def cmd_set_password(args):
    if os.geteuid() != 0:
        error("set-password needs root (sudo).")
        sys.exit(2)
    pw1 = getpass.getpass("New password: ")
    pw2 = getpass.getpass("Repeat: ")
    if pw1 != pw2:
        error("Passwords do not match.")
        sys.exit(1)
    salt, dk = hash_password(pw1)
    save_passfile(salt, dk)

def cmd_clear_password(args):
    if os.geteuid() != 0:
        error("clear-password needs root (sudo).")
        sys.exit(2)
    if PASSFILE.exists():
        PASSFILE.unlink()
        ok("Password cleared.")
    else:
        warn("No password file to clear.")

def require_auth(allow_noauth=False, noauth_flag=False):
    salt, dk = load_passfile()
    if not salt:
        if not allow_noauth:
            warn("No password set. Use set-password to enable protection.")
        return True
    if noauth_flag:
        error("Cannot use --noauth when a password is set.")
        return False
    for _ in range(3):
        if verify_password_interactive():
            ok("Authentication successful.")
            return True
        warn("Incorrect password.")
    error("Authentication failed after 3 attempts.")
    return False

def cmd_scan(args):
    if not require_auth(allow_noauth=True, noauth_flag=getattr(args, "noauth", False)):
        sys.exit(2)
    ports = [22,80,443] if not args.ports else parse_ports(args.ports)
    info(f"Scanning {args.host} ports: {ports}")
    open_ports = scan_host_mt(args.host, ports, timeout=args.timeout, workers=args.workers)
    if open_ports:
        ok("Open ports: " + ", ".join(map(str, open_ports)))
    else:
        info("No open ports found in scanned ports.")
    if args.outdir:
        write_report(args.outdir, args.host, open_ports, fmt=args.format)
    send_telegram_if_configured(f"PortSnap: {args.host} open: {open_ports}")

def cmd_monitor(args):
    if not require_auth(allow_noauth=True, noauth_flag=getattr(args, "noauth", False)):
        sys.exit(2)
    ports = [22,80,443] if not args.ports else parse_ports(args.ports)
    interval = max(1, int(args.interval))
    info(f"Starting monitor for {args.host}. Interval: {interval}s. Ports: {ports}")
    try:
        while True:
            open_ports = scan_host_mt(args.host, ports, timeout=args.timeout, workers=args.workers)
            ts = datetime.utcnow().isoformat() + "Z"
            print(f"[{ts}] {args.host} open: {open_ports}")
            if args.outdir:
                write_report(args.outdir, args.host, open_ports, fmt=args.format)
            send_telegram_if_configured(f"PortSnap monitor: {args.host} open: {open_ports}")
            time.sleep(interval)
    except KeyboardInterrupt:
        info("Monitor stopped by user.")

# Utilities
def parse_ports(s):
    parts = []
    for part in s.split(","):
        part = part.strip()
        if "-" in part:
            a,b = part.split("-",1)
            parts.extend(range(int(a), int(b)+1))
        else:
            parts.append(int(part))
    return sorted(set(parts))

def main():
    print(color(BANNER, "36"))
    print_dashboard()
    parser = argparse.ArgumentParser(prog="portsnap-secure", description="PortSnap Secure - final")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("set-password", help="(root) set password")
    sub.add_parser("clear-password", help="(root) clear password")
    p_scan = sub.add_parser("scan", help="Scan a host once for open TCP ports")
    p_scan.add_argument("host", help="Target host (IP or hostname)")
    p_scan.add_argument("--ports", "-p", help="Comma separated ports or ranges (e.g. 22,80,1000-1010)")
    p_scan.add_argument("--timeout", "-t", type=float, default=0.8, help="TCP connect timeout")
    p_scan.add_argument("--workers", "-w", type=int, default=100, help="Parallel workers (threads)")
    p_scan.add_argument("--outdir", "-o", help="Write a timestamped report to this directory")
    p_scan.add_argument("--format", "-f", choices=["txt","json","csv"], default="txt", help="Report format")
    p_scan.add_argument("--noauth", action="store_true", help="Skip auth (only allowed when no password set)")
    p_scan.set_defaults(func=cmd_scan)
    p_mon = sub.add_parser("monitor", help="Run periodic scans")
    p_mon.add_argument("host", help="Target host (IP or hostname)")
    p_mon.add_argument("--ports", "-p", help="Comma separated ports or ranges")
    p_mon.add_argument("--interval", "-i", default=60, help="Seconds between scans")
    p_mon.add_argument("--timeout", "-t", type=float, default=0.8, help="TCP connect timeout")
    p_mon.add_argument("--workers", "-w", type=int, default=100, help="Parallel workers (threads)")
    p_mon.add_argument("--outdir", "-o", help="Write timestamped reports to this directory")
    p_mon.add_argument("--format", "-f", choices=["txt","json","csv"], default="txt", help="Report format")
    p_mon.add_argument("--noauth", action="store_true", help="Skip auth (only allowed when no password set)")
    p_mon.set_defaults(func=cmd_monitor)
    p_start = sub.add_parser("start", help="Alias to monitor (for systemd)")
    p_start.add_argument("host", help="Target host (IP or hostname)")
    p_start.add_argument("--ports", "-p", help="Comma separated ports or ranges")
    p_start.add_argument("--interval", "-i", default=60, help="Seconds between scans")
    p_start.add_argument("--timeout", "-t", type=float, default=0.8, help="TCP connect timeout")
    p_start.add_argument("--workers", "-w", type=int, default=100, help="Parallel workers (threads)")
    p_start.add_argument("--outdir", "-o", help="Write timestamped reports to this directory")
    p_start.add_argument("--format", "-f", choices=["txt","json","csv"], default="txt", help="Report format")
    p_start.add_argument("--noauth", action="store_true", help="Skip auth (only allowed when no password set)")
    p_start.set_defaults(func=cmd_monitor)
    args = parser.parse_args()
    # Handle set/clear separately
    if args.cmd == "set-password": cmd_set_password(args); return
    if args.cmd == "clear-password": cmd_clear_password(args); return
    # Otherwise run chosen command function
    args.func(args)

if __name__ == "__main__":
    main()
