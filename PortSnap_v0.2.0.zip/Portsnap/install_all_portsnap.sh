#!/usr/bin/env bash
# install_all_portsnap.sh
# سكربت تثبيت كامل لـ PortSnap (نسخ الملفات، صلاحيات، مجلد سجلات، systemd، completion, aliases)
set -euo pipefail

# --- تعديل القيم حسب الحاجة ---
SRC_DIR="$(pwd)"                   # مجلد الملفات المصدر ( portsnap-secure.py و portsnap )
BIN_DIR="/usr/local/bin"
MAIN_SRC="$SRC_DIR/portsnap-secure.py"
WRAPPER_SRC="$SRC_DIR/portsnap"
MAIN_BIN="$BIN_DIR/portsnap-secure"
WRAPPER_BIN="$BIN_DIR/portsnap"
LOGDIR="/var/log/portsnap-secure"
SERVICE_FILE="/etc/systemd/system/portsnap-secure.service"
BASH_COMPLETION_SRC="$SRC_DIR/portsnap-secure.bash-completion"
ZSH_COMP_SRC="$SRC_DIR/_portsnap-secure"
ALIAS_FILE="$HOME/.bashrc"   # غيّر إلى ~/.zshrc إن تستخدم zsh

echo "=== PortSnap full installer ==="

# 0. تحقق من وجود الملفات الأساسية
if [ ! -f "$MAIN_SRC" ]; then
  echo "خطأ: لم أجد $MAIN_SRC. ضع portsnap-secure.py في هذا المجلد ثم أعد التشغيل."
  exit 1
fi

# 1. انسخ السكربت الرئيسي والـ wrapper إلى /usr/local/bin
echo "1) نسخ الملفات إلى $BIN_DIR ..."
sudo install -m 755 "$MAIN_SRC" "$MAIN_BIN"
if [ -f "$WRAPPER_SRC" ]; then
  sudo install -m 755 "$WRAPPER_SRC" "$WRAPPER_BIN"
else
  echo "ملاحظة: ملف wrapper (portsnap) غير موجود — ستمرّر الأوامر مباشرة إلى portsnap-secure."
fi

# 2. أنشئ مجلد السجلات وأعطه ملكية المستخدم الحالي (ليست root)
echo "2) إنشاء مجلد السجلات: $LOGDIR"
sudo mkdir -p "$LOGDIR"
sudo chown "$USER":"$USER" "$LOGDIR"
sudo chmod 755 "$LOGDIR"

# 3. انسخ اكتمال bash و zsh إن وُجدت
if [ -f "$BASH_COMPLETION_SRC" ]; then
  echo "3) تثبيت bash completion ..."
  sudo cp "$BASH_COMPLETION_SRC" /etc/bash_completion.d/portsnap-secure
fi
if [ -f "$ZSH_COMP_SRC" ]; then
  echo "3b) تثبيت zsh completion ..."
  sudo mkdir -p /usr/share/zsh/site-functions
  sudo cp "$ZSH_COMP_SRC" /usr/share/zsh/site-functions/_portsnap-secure
fi

# 4. أضف aliases للـ shell (append إن لم تكن موجودة)
echo "4) إضافة aliases إلى $ALIAS_FILE (إذا لم تكن موجودة)"
grep -qxF "alias psnap='$WRAPPER_BIN'" "$ALIAS_FILE" 2>/dev/null || \
  echo "alias psnap='$WRAPPER_BIN'" >> "$ALIAS_FILE"
grep -qxF "alias psnap-local='$MAIN_BIN'" "$ALIAS_FILE" 2>/dev/null || \
  echo "alias psnap-local='$MAIN_BIN'" >> "$ALIAS_FILE"
echo "أعد فتح الجلسة أو نفّذ: source $ALIAS_FILE"

# 5. اسأل المستخدم إن كان يريد إنشاء service systemd
read -p "هل تريد إنشاء وتفعيل خدمة systemd لتشغيل مراقبة افتراضية عند الإقلاع؟ (y/N): " create_service
if [[ "$create_service" =~ ^([yY][eE][sS]|[yY])$ ]]; then
  read -p "أدخل المضيف الافتراضي للمراقبة (مثال 10.0.2.15) [127.0.0.1]: " srv_host
  srv_host=${srv_host:-127.0.0.1}
  read -p "أدخل الفاصل بالثواني بين الفحوصات (interval) [60]: " srv_interval
  srv_interval=${srv_interval:-60}
  echo "إنشاء service systemd..."
  sudo tee "$SERVICE_FILE" > /dev/null <<EOF
[Unit]
Description=PortSnap Secure periodic snapshot service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$WRAPPER_BIN -g $srv_host --interval $srv_interval --outdir $LOGDIR --format json
Restart=on-failure
User=$USER

[Install]
WantedBy=multi-user.target
EOF
  sudo systemctl daemon-reload
  sudo systemctl enable --now portsnap-secure.service
  echo "Service portsnap-secure.service مُفعّلة."
else
  echo "تخطي إنشاء service systemd."
fi

# 6. تعليمات ما بعد التثبيت
echo
echo "=== انتهى التثبيت ==="
echo "الملفات المنسوخة:"
ls -l "$MAIN_BIN" || true
ls -l "$WRAPPER_BIN" || true
echo "مجلد السجلات: $LOGDIR"
ls -ld "$LOGDIR" || true
echo
echo "لتعيين كلمة مرور للحماية (مهم):"
echo "  sudo $MAIN_BIN set-password"
echo
echo "أمثلة تشغيل:"
echo "  sudo $MAIN_BIN scan 127.0.0.1 -o ~/portsnap_reports -f json"
echo "  portsnap scan 127.0.0.1 -o ~/portsnap_reports -f json   # إن ثبتت wrapper"
echo
echo "إذا أردت إلغاء التثبيت لاحقًا، اطبع: sudo $MAIN_BIN clear-password  ثم حذف الملفات في /usr/local/bin و /var/log/portsnap-secure"
